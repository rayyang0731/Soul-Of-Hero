---
--- $Name
---

---@class $Name
local _M = { _VERSION = "1.0" }

local log = Log.Create("$Name")
----------------------------------------------------------------------------------



return _M