---
--- $NAME
---

---@class $NAME
---@field name string 指令标签名称
local _M = { _VERSION = "1.0" }

local log = Log.Create("$NAME")
----------------------------------------------------------------------------------

--region ----------构造函数----------

function _M:new()
    ---@type AbstractMediator
    local abstractMediator = require("AbstractMediator"):new("$NAME")
    return setmetatable(_M, { __index = abstractMediator })
end

--endregion

--region ----------protected方法----------

---加载时调用
local function OnLoad()
    
end

---卸载时调用
local function OnUnload()
    
end

--endregion

return _M